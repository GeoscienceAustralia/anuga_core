/************************************************************************/
/* PyPAR - Parallel Python using MPI                 	                */
/* Copyright (C) 2001, 2002 Ole M. Nielsen                              */
/* See enclosed README file for details of installation and use.   	*/
/*                                                                 	*/   
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License, or    */
/* (at your option) any later version.                                  */
/*                                                                      */     
/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License (http://www.gnu.org/copyleft/gpl.html)    */
/* for more details.                                                    */
/*                                                                      */
/* You should have received a copy of the GNU General Public License    */
/* along with this program; if not, write to the Free Software          */
/*  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307*/
/*                                                                      */
/*                                                                 	*/
/* Contact address: Ole.Nielsen@anu.edu.au                         	*/
/*                                                                 	*/
/* Version 1.0, October 2001                                       	*/   
/************************************************************************/

#include "Python.h"
#include "mpi.h"
#include "Numeric/arrayobject.h"


MPI_Datatype type_map(PyArrayObject *x) {  

  //
  // TYPE    py_type  mpi_type  bytes  symbol
  // ---------------------------------------- 
  // INT       4        6         4      'i'
  // LONG      5        8         8      'l'
  // FLOAT     6       10         4      'f'  
  // DOUBLE    7       11         8      'd'
  
  
  int py_type;
  MPI_Datatype mpi_type;
  
  if (x -> nd != 1) {
    PyErr_SetString(PyExc_ValueError, "Array must be 1 dimensional");
    return (MPI_Datatype) 0;
  }      
      
  py_type = x -> descr -> type_num;     
  if (py_type == PyArray_DOUBLE) 
    mpi_type = MPI_DOUBLE;
  else if (py_type == PyArray_LONG)   
    mpi_type = MPI_LONG;  
  else if (py_type == PyArray_FLOAT) 
    mpi_type = MPI_FLOAT;
  else if (py_type == PyArray_INT) 
    mpi_type = MPI_INT;
  else {
    PyErr_SetString(PyExc_ValueError, "Array must be of type int or float");
    return 0;
  }      

  //printf("Types %d %d\n", py_type, mpi_type);
  
  return mpi_type;
}    


/*********************************************************/
/* send_string                                           */
/* Send string of characters                             */
/*                                                       */
/*********************************************************/
static PyObject *send_string(PyObject *self, PyObject *args) {
  char *s;
  int destination, tag, length, err;
 
  /* process the parameters */
  if (!PyArg_ParseTuple(args, "s#ii", &s, &length, &destination, &tag))
    return NULL;
  
  /* call the MPI routine */
  err = MPI_Send(s, length, MPI_CHAR, destination, tag, MPI_COMM_WORLD);

  return Py_BuildValue("i", err);
}

/**********************************************************/
/* receive_string                                         */
/* Receive string of characters                           */
/*                                                        */
/**********************************************************/
static PyObject *receive_string(PyObject *self, PyObject *args) {
  char *s;
  int source, tag, length, err; 
  MPI_Status status;

  /* process the parameters */
  if (!PyArg_ParseTuple(args, "s#ii", &s, &length, &source, &tag))
    return NULL;
    
  /* call the MPI routine */
  err = MPI_Recv(s, length, MPI_CHAR, source, tag, MPI_COMM_WORLD, &status);
   
  return Py_BuildValue("i", err);  
}

/**********************************************************/
/* bcast_string                                           */
/* Broadcast string of characters                         */
/*                                                        */
/**********************************************************/
static PyObject *bcast_string(PyObject *self, PyObject *args) {
  char *s;
  int source, length, err; 

  /* process the parameters */
  if (!PyArg_ParseTuple(args, "s#i", &s, &length, &source))
    return NULL;
    
  /* call the MPI routine */
  err = MPI_Bcast(s, length, MPI_CHAR, source, MPI_COMM_WORLD);
   
  return Py_BuildValue("i", err);  
}

/**********************************************************/
/* send_array                                             */
/* Send Numeric array of type float, double, int, or long */
/*                                                        */
/**********************************************************/
static PyObject *send_array(PyObject *self, PyObject *args) {
  PyObject *input;
  PyArrayObject *x;
  int destination, tag, err;
  MPI_Datatype mpi_type;
  
  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oii", &input, &destination, &tag))
    return NULL;
    
  /* Make Numeric array from general sequence type (no cost if already Numeric)*/    
  x = (PyArrayObject *)
    PyArray_ContiguousFromObject(input, PyArray_NOTYPE, 0, 0);
    
  /* Input check and determination of MPI type */          
  mpi_type = type_map(x);
  if (!mpi_type) return NULL;
    
  /* call the MPI routine */
  err = MPI_Send(x->data, x->dimensions[0], mpi_type, destination, tag,\
           MPI_COMM_WORLD);
	   
  Py_DECREF(x); 	   
	   
  return Py_BuildValue("i", err);
}

/*************************************************************/
/* receive_array                                             */
/* Receive Numeric array of type float, double, int, or long */
/*                                                           */
/*************************************************************/
static PyObject *receive_array(PyObject *self, PyObject *args) {
  PyArrayObject *x;
  int source, tag, err;
  MPI_Datatype mpi_type;
  MPI_Status status;

  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oii", &x, &source, &tag))
    return NULL;

  /* Input check and determination of MPI type */          
  mpi_type = type_map(x);
  if (!mpi_type) return NULL;  
      
  /* call the MPI routine */
  err =  MPI_Recv(x->data, x->dimensions[0], mpi_type, source, tag, \
         MPI_COMM_WORLD, &status);
      
  return Py_BuildValue("i", err);
}


/*************************************************************/
/* bcast_array                                               */
/* Broadcast Num.  array of type float, double, int, or long */
/*                                                           */
/*************************************************************/
static PyObject *bcast_array(PyObject *self, PyObject *args) {
  PyArrayObject *x;
  int source, err;
  MPI_Datatype mpi_type;
  MPI_Status status;

  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oi", &x, &source))
    return NULL;

  /* Input check and determination of MPI type */          
  mpi_type = type_map(x);
  if (!mpi_type) return NULL;  
      
  /* call the MPI routine */
  err =  MPI_Bcast(x->data, x->dimensions[0], mpi_type, source, \
         MPI_COMM_WORLD);
      
  return Py_BuildValue("i", err);
}




/*********************************************************/
/* send_real_array                                       */
/* Send Numeric array of double floating point numbers   */
/*                                                       */
/*********************************************************/
static PyObject *send_real_array(PyObject *self, PyObject *args) {
  PyObject *input;
  PyArrayObject *x;
  int destination, tag, err;
  
  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oii", &input, &destination, &tag))
    return NULL;

  /* Make Numeric array from general sequence type (no cost if already Numeric)*/    
  x = (PyArrayObject *)
    PyArray_ContiguousFromObject(input, PyArray_DOUBLE, 0, 0);

  /* call the MPI routine */
  err = MPI_Send(x->data, x->dimensions[0], MPI_DOUBLE, destination, tag,\
           MPI_COMM_WORLD);

  Py_DECREF(x); 	   	   	   
  return Py_BuildValue("i", err);
}

/**********************************************************/
/* receive_real_array                                     */
/* Receive Numeric array of double floating point numbers */
/*                                                        */
/**********************************************************/
static PyObject *receive_real_array(PyObject *self, PyObject *args) {
  PyArrayObject *x;
  int source, tag, err;
  MPI_Status status;

  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oii", &x, &source, &tag))
    return NULL;
  
  /* call the MPI routine */
  err =  MPI_Recv(x->data, x->dimensions[0], MPI_DOUBLE, source, tag, \
         MPI_COMM_WORLD, &status);


  return Py_BuildValue("i", err);
}

/************************************************************/
/* bcast_real_array                                         */
/* Broadcast Numeric array of double floating point numbers */
/*                                                          */
/************************************************************/
static PyObject *bcast_real_array(PyObject *self, PyObject *args) {
  PyArrayObject *x;
  int source, err;


  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oi", &x, &source))
    return NULL;
  
  /* call the MPI routine */
  err =  MPI_Bcast(x->data, x->dimensions[0], MPI_DOUBLE, source, \
         MPI_COMM_WORLD);


  return Py_BuildValue("i", err);
}
/*********************************************************/
/* send_int_array                                        */
/* Send Numeric array of long integers                   */
/*                                                       */
/*********************************************************/
static PyObject *send_int_array(PyObject *self, PyObject *args) {
  PyObject *input;
  PyArrayObject *x;
  int destination, tag, err;
  
  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oii", &input, &destination, &tag))
    return NULL;
    
  /* Make Numeric array from general sequence type */        
  x = (PyArrayObject *)
    PyArray_ContiguousFromObject(input, PyArray_LONG, 0, 0);
     
  /* call the MPI routine */
  err = MPI_Send(x->data, x->dimensions[0], MPI_LONG, destination, tag, \
        MPI_COMM_WORLD);

  Py_DECREF(x); 	   	
  return Py_BuildValue("i", err);
}

/**********************************************************/
/* receive_int_array                                      */
/* Receive Numeric array of long integers                 */
/*                                                        */
/**********************************************************/
static PyObject *receive_int_array(PyObject *self, PyObject *args) {
  PyArrayObject *x;
  int source, tag, err;
  MPI_Status status;

  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oii", &x, &source, &tag))
    return NULL;
    
  /* call the MPI routine */
  err =  MPI_Recv(x->data, x->dimensions[0], MPI_LONG, source, tag, \
         MPI_COMM_WORLD, &status);
      
  return Py_BuildValue("i", err);
}

/**********************************************************/
/* bcast_int_array                                        */
/* Broadcast Numeric array of long integers               */
/*                                                        */
/**********************************************************/
static PyObject *bcast_int_array(PyObject *self, PyObject *args) {
  PyArrayObject *x;
  int source, err;

  /* process the parameters */
  if (!PyArg_ParseTuple(args, "Oii", &x, &source))
    return NULL;
    
  /* call the MPI routine */
  err =  MPI_Bcast(x->data, x->dimensions[0], MPI_LONG, source, \
         MPI_COMM_WORLD);
      
  return Py_BuildValue("i", err);
}

/*********************************************************/
/* MPI calls rank, size, finalize, abort                 */
/*                                                       */
/*********************************************************/

static PyObject * rank(PyObject *self, PyObject *args) {
  int myid;

  MPI_Comm_rank(MPI_COMM_WORLD,&myid);
  return Py_BuildValue("i", myid);
}

static PyObject * size(PyObject *self, PyObject *args) {
  int numprocs; 

  MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
  return Py_BuildValue("i", numprocs);
}
  
static PyObject * Get_processor_name(PyObject *self, PyObject *args) {  
  char processor_name[MPI_MAX_PROCESSOR_NAME];
  int  namelen;

  MPI_Get_processor_name(processor_name,&namelen);
  return Py_BuildValue("s#", processor_name, namelen);
}   
  
static PyObject * Finalize(PyObject *self, PyObject *args) {  
  int error;

  error = MPI_Finalize();
  return Py_BuildValue("i", error);  
} 

static PyObject * Abort(PyObject *self, PyObject *args) {  
  int error, code=0;
  
  error = MPI_Abort(MPI_COMM_WORLD, code);
  return Py_BuildValue("i", error);  
} 

static PyObject * Barrier(PyObject *self, PyObject *args) {  
  int error;
  
  error = MPI_Barrier(MPI_COMM_WORLD);
  return Py_BuildValue("i", error);    
}    

static PyObject * Wtime(PyObject *self, PyObject *args) {     
  double t;
  
  t = MPI_Wtime();
  return Py_BuildValue("d", t);      
}     
 
/**********************************/
/* Method table for python module */
/**********************************/

static struct PyMethodDef MethodTable[] = {
  {"size", size, METH_VARARGS},  
  {"rank", rank, METH_VARARGS},  
  {"Barrier", Barrier, METH_VARARGS},          
  {"Wtime", Wtime, METH_VARARGS},            
  {"Get_processor_name", Get_processor_name, METH_VARARGS},              
  {"Finalize", Finalize, METH_VARARGS},        
  {"Abort", Abort, METH_VARARGS},          
  {"send_string", send_string, METH_VARARGS},
  {"receive_string", receive_string, METH_VARARGS},      
  {"bcast_string", bcast_string, METH_VARARGS},      
  {"send_array", send_array, METH_VARARGS},
  {"receive_array", receive_array, METH_VARARGS},        
  {"bcast_array", bcast_array, METH_VARARGS},        
  {"send_real_array", send_real_array, METH_VARARGS},
  {"receive_real_array", receive_real_array, METH_VARARGS},        
  {"bcast_real_array", bcast_real_array, METH_VARARGS},        
  {"send_int_array", send_int_array, METH_VARARGS},
  {"receive_int_array", receive_int_array, METH_VARARGS},          
  {"bcast_int_array", bcast_int_array, METH_VARARGS},          
  {NULL, NULL}
};


/***************************/
/* Initialisation Function */
/***************************/

void initmpi(){
  int error, argc = 0; //Dummy
  char **argv;         //Dummy

  //printf("Initialising MPI\n");
  error = MPI_Init(&argc, &argv); 
  //printf("MPI Initialised\n");  
  
  (void) Py_InitModule("mpi", MethodTable);
  import_array();     //Necessary for handling of NumPY structures  
}

 

/****************************************/
/* Superfluous now, but keep for doc of */
/* how to access Numeric arrays         */ 
/****************************************/

void print_real_array(PyArrayObject *x) {  
  int i;
  for (i=0; i<x->dimensions[0]; i++) {
    printf("%f ", *(double*) (x->data + i*x->strides[0]));
  }
}

void print_int_array(PyArrayObject *x) {  
  int i;
  for (i=0; i<x->dimensions[0]; i++) {
    printf("%d ", *(int*) (x->data + i*x->strides[0]));
  }
}

 


