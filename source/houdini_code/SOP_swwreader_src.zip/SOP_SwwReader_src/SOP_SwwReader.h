#ifndef __SOP_SwwReader_h__
#define __SOP_SwwReader_h__

#include <SOP/SOP_Node.h>
#include <vector>

#define FLT_PARM(name, idx, vi, t)	\
		return evalFloat(name, &myIndirect[idx], vi, t);
#define INT_PARM(name, idx, vi, t)	\
		return evalInt(name, &myIndirect[idx], vi, t);
#define STR_PARM(name, idx, vi, t)	\
		evalString(str, name, &myIndirect[idx], vi, (float)t);

class SOP_SwwReader : public SOP_Node
{
public:
    static OP_Node		*myConstructor(OP_Network*, const char *,
							    OP_Operator *);
    static PRM_Template		 myTemplateList[];

protected:
	     SOP_SwwReader(OP_Network *net, const char *name, OP_Operator *op);
    virtual ~SOP_SwwReader();

    virtual unsigned		 disableParms();
    virtual OP_ERROR		 cookMySop(OP_Context &context);

    // stack of return values from netcdf function calls
    std::vector<int> _status;

    // error checker (iterates through _status stack)
    bool _statusHasError();

    bool openSwwFile(const char *filename);
    bool _netcdf_opened;
    bool _arrays_allocated;
    void cleanupArrays();

    // netCDF file id
    int _ncid;

    // netcdf dimension ids
    int _nvolumesid, _nverticesid, _npointsid, _ntimestepsid;

    // netcdf dimension values
    size_t _nvolumes, _nvertices, _npoints, _ntimesteps;

    // netcdf variable ids
    int _xid, _yid, _zid, _volumesid, _timeid, _stageid;

    // netcdf variable values (allocated in constructor)
    float *_px, *_py, *_pz, *_ptime, *_pstage;
    unsigned int *_pvolumes;

    // global attributes we're interested in
    float _xllcorner,_yllcorner;

    enum {STAGES,ELEVATION} _geo_mode;

    bool _need_uvs;
    bool _need_points;
    bool _full_topology;
    void restoreFullTopology();
    void deleteTopology();
    void deleteAllGeo();

    void readStage(int timestep);

    // only build the topology that isn't hidden from a viewer above
    // the scene
    void buildCulledTopology();

private:

    UT_String		_my_current_file;
    void FNAME(UT_String &str, float t)	{ STR_PARM("file",0,0,t) }
    int  GEO(float t)                   { INT_PARM("geo",1,0,t) }
    int  CULLHIDDEN(float t)            { INT_PARM("cullhidden",2,0,t) }
    int  TIME(float t)                  { INT_PARM("timestep",3,0,t) }
    int   DEPTH(float t)                { INT_PARM("depth",4,0,t) }
    float MAPOX(float t)                { FLT_PARM("map_origin",5,0,t) }
    float MAPOY(float t)                { FLT_PARM("map_origin",5,1,t) }
    float PIXELXSIZE(float t)           { FLT_PARM("pixelsize",6,0,t) }
    float PIXELYSIZE(float t)           { FLT_PARM("pixelsize",6,1,t) }
    int   MAPXRES(float t)              { INT_PARM("mapres",7,0,t) }
    int   MAPYRES(float t)              { INT_PARM("mapres",7,1,t) }

    float _mapox,_mapoy;
    float _pixelxsize,_pixelysize;
    int _mapxres,_mapyres;

    static int	*myIndirect;
 
};

#undef FLT_PARM
#undef INT_PARM
#undef STR_PARM
#endif
