//    Hey emacs, this is -*- c++ -*- code.

//
//     November 2005.
//     Drew.Whitehouse@anu.edu.au
//
//     $Id:$ 
// 

//     Copyright (C) 2005  Drew Whitehouse, ANU Supercomputer Facility
//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

/*

TODO:

 1. add quantities like xmomentum etc
 2. can the optional quantities be dynamically setup ?

*/



#include "netcdf.h"
#include <limits.h>
#include <UT/UT_DSOVersion.h>
#include <UT/UT_Math.h>
#include <UT/UT_Vector3.h>
#include <UT/UT_Interrupt.h>
#include <GU/GU_Detail.h>
#include <GU/GU_PrimPoly.h>
#include <GB/GB_Group.h>
#include <CH/CH_LocalVariable.h>
#include <PRM/PRM_Include.h>
#include <OP/OP_Operator.h>
#include <OP/OP_OperatorTable.h>

#include "SOP_SwwReader.h"

//
// Help may be embedded in the C file or stored externally as plain text, HTML
// or XML. The recommended approach is to use external files for custom help.
// Below, we sub-class off of OP_Operator to demonstrate embedding help in the
// C source file.
//
// In either case, for help content that is HTML or XML the required content
// identifier must be present. Use one of the following conventions:
//	HTML Content Prefix:
//		<HTML>
//		<!DOCTYPE HTML [.../>]
//	XML Content Prefix:
//		<?XML [.../>]
//		<!DOCTYPE XML [.../>]
//
// Note, that the content identifiers are not case sensitive and should be
// located at the start of the file or text. Any text within [...] is not
// used as part of the content type check.
//
// To use an external help file, simply copy the file into the location:
//	[$Houdini]/config/Help/[script directory]/[type name][extension]
//
//  EG. /home/user/houdini8.0/config/Help/sop/star.html
//
// The path must be accessible from the Houdini path. Valid extensions are
// .xml, .html or no extension. Houdini will search for help files in that
// order using the first matching file. 
//
// For external help files the content type identifier is used by the
// browser in conjunction with the file extension to determine its type.
// So if a file is to be interpreted as plain text, then it should not be
// given a .html or .xml extension, even though it does not contain a
// content type identifier indicating it as html or xml.
//

class OP_SwwReaderOperator : public OP_Operator {
public:
	     OP_SwwReaderOperator();
    virtual ~OP_SwwReaderOperator();

    virtual bool	getHDKHelp(UT_String &str) const;
};

OP_SwwReaderOperator::OP_SwwReaderOperator()
    : OP_Operator("swwreader",
		  "SwwReader",
		  SOP_SwwReader::myConstructor,
		  SOP_SwwReader::myTemplateList,
		  0,
		  0,
                  0,
		  OP_FLAG_GENERATOR)
{

}

OP_SwwReaderOperator::~OP_SwwReaderOperator()
{
    // nothing
}

bool
OP_SwwReaderOperator::getHDKHelp(UT_String &help) const
{
    // This is plain text version of the star sop's help.
    // ** Plain text does not provide any formatting options,  **
    // ** but it is straight-forward and quick to produce.     **
    /*
      help  = "SwwReader SOP builds stars of N points\n\n";
      help += "Parameters:\n";
      help += "   Divisions:   Number of points on the star\n";
      help += "   Radius:      Radius of the star\n";
      help += "   NegRadius:   Allow the radius to be negative\n";
      help += "                This may create bowtie polygons\n";
      help += "   Center:      The center point of the star\n";
      help += "   Orientaion:  The orientation of the star\n";
      help += "\n";
      help += "Local Variables:\n";
      help += "  $PT  - current point number\n";
      help += "  $NPT - number of points in the star\n";
    */

    // This is an html version of the star sop's help.
    // ** HTML allows flexible formatting of your help content **
    // ** and embedding of images and links.		       **
//     help  = "<html><body>";
//     help += "<b><h2>SwwReader SOP reads pyVolution sww files</h2></b>";
//     help += "<hr/>";
//     help += "<h3><u>Parameters:</u></h3>";
//     help += "<table border=\"0\" width=\"100%\">";
//     help += "  <tr>";
//     help += "    <td width=\"150\"><b>Divisions:</b></td>";
//     help += "    <td width=\"350\">Number of points on the star</td>";
//     help += "  </tr>";
//     help += "  <tr>";
//     help += "    <td><b>Radius:</b></td>";
//     help += "    <td>Radius of the star</td>";
//     help += "  </tr>";
//     help += "  <tr>";
//     help += "    <td><b>NegRadius:</b></td>";
//     help += "    <td>Allow the radius to be negative</td>";
//     help += "  </tr>";
//     help += "  <tr>";
//     help += "    <td></td>";
//     help += "    <td>this may create bowtie polygons</td>";
//     help += "  </tr>";
//     help += "  <tr>";
//     help += "    <td><b>Center:</b></td>";
//     help += "    <td>The center point of the star</td>";
//     help += "  </tr>";
//     help += "  <tr>";
//     help += "    <td><b>Orientation:</b></td>";
//     help += "    <td>The orientation of the star</td>";
//     help += "  </tr>";
//     help += "</table>";
//     help += "<br/>";
//     help += "<h3><u>Local Variables:</u></h3>";
//     help += "<ul>";
//     help += "  <li>$PT  - current point number</li>";
//     help += "  <li>$NPT  - number of points in the star</li>";
//     help += "</ul>";
//     help += "</body></html>";

    // XML version of star sop's help is not included
    // ** XML allows separation of help content and formating  **
    // ** rules using XSL stylesheets, ensuring that all your  **
    // ** help files always have a consistent look.            **
    
    // Note: HDK developers are discouraged from embedding help
    // in their C files and should use external help when possible.

    // The getHDKHelp() must return true if it is to be used in place of 
    // other forms of help (eg. custom, OTL, or Houdini help).
    return true;
}

void
newSopOperator(OP_OperatorTable *table)
{
#if 0
    // If we want to use the "standard" operator class, we can do this here.
    // However, the OP_SwwReaderOperator has the help built in and requires a
    // custom operator.
    table->addOperator(
        new OP_Operator("swwreader",			// Internal name
                        "SwwReader",			// UI name
                        SOP_SwwReader::myConstructor,	// How to build the SOP
                        SOP_SwwReader::myTemplateList,	// My parameters
                        0,				// Min # of sources
                        0,				// Max # of sources
                        0,	// Local variables
                        OP_FLAG_GENERATOR)		// Flag it as generator
        );
#else
    table->addOperator(new OP_SwwReaderOperator());
#endif
}

static PRM_Name paramNames[] = 
{
    PRM_Name("file",    "File Name"),
    PRM_Name("geo",     "Geometry"),
    PRM_Name("cullhidden","Remove hidden surface"),
    PRM_Name("timestep","Time Step"),
    PRM_Name("depth","Depth Attribute"),
    PRM_Name("map_origin","Map Origin"),
    PRM_Name("pixelsize","Map Pixel Size(m)"),
    PRM_Name("mapres","Map Pixel Resolution"),
        
};

static PRM_Default fileDef(0,"$HIP/test.sww");
static PRM_Default timestepDef(0,"$F-1");
static PRM_Range   pixelsizeRange(PRM_RANGE_RESTRICTED,0.001,PRM_RANGE_FREE);
static PRM_Range   resRange(PRM_RANGE_RESTRICTED,1,PRM_RANGE_FREE);

static PRM_Name		geoMenuNames[] = 
{
    PRM_Name("elevation", "Elevation"),
    PRM_Name("stages",   "Stages"),
    PRM_Name(0)
};
#define PRM_MENU_CHOICES	(PRM_ChoiceListType)(PRM_CHOICELIST_EXCLUSIVE |\
						     PRM_CHOICELIST_REPLACE)

static PRM_ChoiceList	geoMenu(PRM_MENU_CHOICES,geoMenuNames);


PRM_Template
SOP_SwwReader::myTemplateList[] = 
{
    PRM_Template(PRM_FILE,	1, &paramNames[0], &fileDef),
    PRM_Template((PRM_Type) PRM_ORD,PRM_Template::PRM_EXPORT_MAX,1,&paramNames[1],0,&geoMenu),
    PRM_Template(PRM_TOGGLE,	1, &paramNames[2], PRMzeroDefaults),
    PRM_Template(PRM_INT_J,	1, &paramNames[3], &timestepDef),
    PRM_Template(PRM_TOGGLE,	1, &paramNames[4], PRMzeroDefaults),
    PRM_Template(PRM_FLT_J,	2, &paramNames[5], PRMzeroDefaults),
    PRM_Template(PRM_FLT_J,	2, &paramNames[6], PRMoneDefaults),
    PRM_Template(PRM_INT_J,	2, &paramNames[7], PRMoneDefaults,0,&resRange),
    PRM_Template()
};

int* SOP_SwwReader::myIndirect = 0;

OP_Node *
SOP_SwwReader::myConstructor(OP_Network *net, const char *name, OP_Operator *op)
{
    return new SOP_SwwReader(net, name, op);
}

SOP_SwwReader::SOP_SwwReader(OP_Network *net, const char *name, OP_Operator *op)
    : SOP_Node(net, name, op) ,
      _full_topology(false),
      _need_points(true),
      _need_uvs(true),
      _arrays_allocated(false),
      _netcdf_opened(false),
      _mapox(0),_mapoy(0),
      _mapxres(1),_mapyres(1),
      _pixelxsize(1),_pixelysize(1)
{
    if (!myIndirect) myIndirect = allocIndirect(32);
}

SOP_SwwReader::~SOP_SwwReader() 
{
    cleanupArrays();
    if (_netcdf_opened)
    {
        nc_close(_ncid);
        _netcdf_opened = false;
    }
}

unsigned
SOP_SwwReader::disableParms()
{
    unsigned changed = 0;
    changed += enableParm("timestep",GEO(0) ? 1 : 0);
    return changed;
}

bool 
SOP_SwwReader::_statusHasError()
{
    bool haserror = false;  // assume success, trap failure

    std::vector<int>::iterator iter;
    for (iter=_status.begin(); iter != _status.end(); iter++)
    {
        if (*iter != NC_NOERR)
        {
            //osg::notify(osg::WARN) << nc_strerror(*iter) <<  std::endl;
            haserror = true;
            nc_close(_ncid);
            _netcdf_opened = false;
            break;
        }
    }

    // on return start gathering result values afresh
    _status.clear();

    return haserror;
}

void 
SOP_SwwReader::cleanupArrays()
{
    if (_arrays_allocated)
    {
        delete[] _px;
        delete[] _py;
        delete[] _pz;
        delete[] _ptime;
        delete[] _pvolumes;
        delete[] _pstage;
        _arrays_allocated = false;
    }
}

bool 
SOP_SwwReader::openSwwFile(const char *filename)
{
    if (_netcdf_opened)
    {
        nc_close(_ncid);
        _netcdf_opened = false;
    }

    cleanupArrays();

    // load the sww file
    _status.push_back(nc_open(filename,NC_NOWRITE,&_ncid));
    if (this->_statusHasError()) return false;

    _netcdf_opened = true;

    // dimension ids
    _status.push_back( nc_inq_dimid(_ncid, "number_of_volumes", &_nvolumesid) );
    _status.push_back( nc_inq_dimid(_ncid, "number_of_vertices", &_nverticesid) );
    _status.push_back( nc_inq_dimid(_ncid, "number_of_points", &_npointsid) );
    _status.push_back( nc_inq_dimid(_ncid, "number_of_timesteps", &_ntimestepsid) );
    if (this->_statusHasError()) return false;

    // dimension values
    _status.push_back( nc_inq_dimlen(_ncid, _nvolumesid, &_nvolumes) );
    _status.push_back( nc_inq_dimlen(_ncid, _nverticesid, &_nvertices) );
    _status.push_back( nc_inq_dimlen(_ncid, _npointsid, &_npoints) );
    _status.push_back( nc_inq_dimlen(_ncid, _ntimestepsid, &_ntimesteps) );
    if (this->_statusHasError()) return false;

    // variable ids
    _status.push_back( nc_inq_varid (_ncid, "x", &_xid) );
    _status.push_back( nc_inq_varid (_ncid, "y", &_yid) );
    _status.push_back( nc_inq_varid (_ncid, "z", &_zid) );
    _status.push_back( nc_inq_varid (_ncid, "volumes", &_volumesid) );
    _status.push_back( nc_inq_varid (_ncid, "time", &_timeid) );
    _status.push_back( nc_inq_varid (_ncid, "stage", &_stageid) );
    if (this->_statusHasError()) return false;

    _px = new float[_npoints];
    _py = new float[_npoints];
    _pz = new float[_npoints];
    _ptime = new float[_ntimesteps];
    _pvolumes = new unsigned int[_nvertices * _nvolumes];
    _pstage = new float[_npoints];
    _arrays_allocated = true;

    // loading variables from netcdf file
    _status.push_back( nc_get_var_float (_ncid, _xid, _px) );  // x vertices
    _status.push_back( nc_get_var_float (_ncid, _yid, _py) );  // y vertices
    _status.push_back( nc_get_var_float (_ncid, _zid, _pz) );  // elevation heights
    _status.push_back( nc_get_var_float (_ncid, _timeid, _ptime) );  // time array
    _status.push_back( nc_get_var_int (_ncid, _volumesid, (int *) _pvolumes) );  // triangle indices
    if (this->_statusHasError()) return false;

    // some global attributes
    _status.push_back(nc_get_att_float (_ncid,NC_GLOBAL,"xllcorner",&_xllcorner));
    _status.push_back(nc_get_att_float (_ncid,NC_GLOBAL,"yllcorner",&_yllcorner));
    if (this->_statusHasError()) return false;

    return true;
}

void 
SOP_SwwReader::deleteAllGeo()
{
    gdp->clearAndDestroy();
    _need_points = true;
    _need_uvs = true;
    _full_topology = false;
}

void
SOP_SwwReader::deleteTopology()
{
    // delete all the current primitives ?
    for (int iprim = _nvolumes-1 ; iprim >= 0 ; --iprim)
    {
        gdp->deletePrimitive(iprim);
    }

    _full_topology = false;
}

void
SOP_SwwReader::buildCulledTopology()
{
    GEO_Point		*ppt;
    GU_PrimPoly		*poly;

    deleteTopology();

    bool use;
    bool lt;
    bool gt;
    bool equal;
    for (int i = 0; i < _nvolumes ; ++i)
    {
        equal = true;
        use = false;

        lt = false;
        gt = false;
            
        for (int j = 0 ; j < _nvertices ; ++j)
        {
            int ip = _pvolumes[i * _nvertices + j];
            equal = equal && (_pstage[ip] == _pz[ip]);
            lt    = lt  || (_pstage[ip] < _pz[ip]);
            gt    = gt   || (_pstage[ip] > _pz[ip]);
        }

        if (lt && gt) // crossed
        {
            use = true;
        }

        else if (_geo_mode == ELEVATION)
        {
            if (equal || lt)
            {
                use = true;
            }
        }
        else if (_geo_mode == STAGES)
        {
            if  (!equal || gt)
            {
                use = true;
            }
        }

        if (use)
        {
            poly = GU_PrimPoly::build(gdp,_nvertices,GU_POLY_CLOSED,0);
            for (int j = 0 ; j < _nvertices ; ++j)
            {
                int ip = _pvolumes[i * _nvertices + j];
                ppt = gdp->points()(ip);
                poly->setVertex(j,ppt);
            }
        }
    }
}

void
SOP_SwwReader::restoreFullTopology()
{
    GEO_Point		*ppt;
    GU_PrimPoly		*poly;

    if (_full_topology)
    {
        return;
    }

    deleteTopology();

    for (int i = 0 ; i < _nvolumes ; ++i)
    {
        poly = GU_PrimPoly::build(gdp,_nvertices,GU_POLY_CLOSED,0);
        for (int j = 0 ; j < _nvertices ; ++j)
        {
            ppt = gdp->points()(_pvolumes[i*_nvertices + j]);
            poly->setVertex(j,ppt);
        }                    
    }

    _full_topology = true;
}

OP_ERROR
SOP_SwwReader::cookMySop(OP_Context &context)
{
    int i;
    GEO_Point *ppt;
    UT_Interrupt *boss;
    UT_String fname;
    static float zero = 0.0;		// attrib initializer
    float now = context.myTime;

    // gdp attribs
    int uvIndex;
    int timeIndex;
    int depthIndex;


    _geo_mode = (GEO(now) == 1) ? STAGES : ELEVATION;

    // does the file needs re-opening ?
    FNAME(fname,now);
    if (_my_current_file != fname)
    {
        if (!openSwwFile((const char*)fname))
        {
            addCommonError(UT_CE_FILE_ERROR, (const char *)fname);
            return error();
        }

        _my_current_file.harden(fname);
        deleteAllGeo();
    }

    // if we aren't in the correct time range, don't output any geometry
    if (TIME(now) < 0 || TIME(now) >= _ntimesteps)
    {
        deleteAllGeo();
        return error();
    }

    if (_need_points)
    {
        for (i = 0 ; i < _npoints ; ++i)
        {
            ppt = gdp->appendPoint();
            ppt->getPos().assign(_px[i],_py[i],0,1);
        }
        _need_points = false;
        _need_uvs = true;
    }

    uvIndex = gdp->addPointAttrib("uv",3*sizeof(float),GB_ATTRIB_FLOAT,&zero);
    timeIndex = gdp->addAttrib("time", sizeof(float), GB_ATTRIB_FLOAT,&zero);

    if (DEPTH(now))
    {
        depthIndex = gdp->addPointAttrib("depth", sizeof(float), GB_ATTRIB_FLOAT,&zero);
    }
    else
    {
        gdp->destroyPointAttrib("depth", sizeof(float), GB_ATTRIB_FLOAT);
    }

    _need_uvs = (_need_uvs || 
                 _mapox != MAPOX(now) || 
                 _mapoy != MAPOY(now) ||
                 _mapxres != MAPXRES(now) || 
                 _mapyres != MAPYRES(now) || 
                 _pixelxsize != PIXELXSIZE(now) ||
                 _pixelysize != PIXELYSIZE(now));
    

    _mapox = MAPOX(now);
    _mapoy = MAPOY(now);
    _mapxres = MAPXRES(now);
    _mapyres = MAPYRES(now);
    _pixelxsize = PIXELXSIZE(now);
    _pixelysize = PIXELYSIZE(now);

    // Check to see that there hasn't been a critical error in cooking the SOP.
    if (error() < UT_ERROR_ABORT)
    {
        // the interrupt server
        boss = UTgetInterrupt();
        boss->opStart("Updating Sww");

        // update the detail attribute for this timestep
        float *ta = (float*)gdp->attribs().getAttribData(timeIndex);
        *ta = _ptime[TIME(now)];

        // read height of the stage
        if ((_geo_mode == ELEVATION && CULLHIDDEN(now)) || _geo_mode == STAGES)
        {
            size_t start[2], count[2];
            const ptrdiff_t stride[2] = {1,1};
            start[0] = TIME(now);
            start[1] = 0;
            count[0] = 1;
            count[1] = _npoints;
                                        
            if (!nc_get_vars_float (_ncid,_stageid, start, count, stride, _pstage) == NC_NOERR )
            {                                
                addCommonError(UT_CE_FILE_ERROR, (const char *)fname);
            }

        }

        // update the points
        switch (_geo_mode)
        {
        case ELEVATION:
        {
            for (i = 0 ; i < _npoints ; ++i)
            {
                ppt = gdp->points()(i);
                ppt->getPos()(2) = _pz[i];
            }
        }
        break;

        case STAGES:
        {
            for (i = 0 ; i < _npoints ; ++i)
            {
                ppt = gdp->points()(i);
                ppt->getPos()(2) = _pstage[i];
            }
        }
        break;
        default:
            std::cerr << "bug alert (switch(_geo_mode)) in SOP_SwwReader.C\n";
            break;
        }

        // force houdini to recalculate the normals that it's using for opengl
        // display purposes
        gdp->destroyPointAttrib("internalN", sizeof(UT_Vector3), GB_ATTRIB_MIXED);

        if (_need_uvs)
        {
            float  xs = _pixelxsize * _mapxres;
            float  ys = _pixelysize * _mapyres;

            // for safety ...
            xs = xs==0.0 ? 0.00001 : xs;
            ys = ys==0.0 ? 0.00001 : ys;

            for (i = 0 ; i < _npoints ; ++i)
            {
                ppt = gdp->points()(i);

                // the texture coords ...
                float *uv = (float*)ppt->getAttribData(uvIndex);

                uv[0] =       (_px[i] + _xllcorner - _mapox) / xs;
                uv[1] = 1.0 - (_py[i] + _yllcorner - _mapoy) / ys;
                uv[2] = 0.0;
            }
            _need_uvs = false;
        }

        // depth attribute ?
        if (DEPTH(now))
        {
            for (i = 0 ; i < _npoints ; ++i)
            {
                ppt = gdp->points()(i);
                float *d = (float*)ppt->getAttribData(depthIndex);
                *d = _pz[i] - _pstage[i];
            }
        }


        // finally build the geometry
        if (CULLHIDDEN(now))
        {
            buildCulledTopology();
        }
        else 
        {
            restoreFullTopology();
        }

        // Tell the interrupt server that we've completed
        boss->opEnd();
    }

    return error();
}
